# 📈 Stock Price Prediction using LSTM & GRU

This project predicts **next-day stock closing prices** using deep learning models (LSTM/GRU).  
It demonstrates **time-series forecasting** with feature engineering, model training, evaluation, and prediction.

⚠️ Disclaimer: This is an **educational project only**. Do not use for financial decisions.

---

## 🚀 Features
- Data collection with `yfinance`
- Feature engineering (SMA, RSI, MACD, log returns)
- Proper **time-series train/val/test split**
- Sliding window sequence creation
- LSTM & GRU models with Keras/TensorFlow
- Metrics: RMSE, MAE, MAPE + Naive baseline
- Save & load models, scalers, configs
- Simple `predict.py` for next-day prediction

---

## 📂 Project Structure
```
StockPricePrediction/
├── data/           # Raw/processed stock data
├── models/         # Saved trained models
├── artifacts/      # Scaler, configs
├── outputs/        # Metrics, predictions
├── src/            # Source code
│   ├── utils.py    # Indicators, preprocessing
│   ├── model.py    # Model builder (LSTM/GRU)
│   ├── train.py    # Training pipeline
│   └── predict.py  # Prediction script
├── requirements.txt
└── README.md
```

---

## ⚡ Quickstart

1. **Setup environment**
```bash
python -m venv .venv
source .venv/bin/activate  # macOS/Linux
.venv\Scripts\activate   # Windows
pip install -r requirements.txt
```

2. **Train a model**
```bash
python src/train.py --ticker AAPL --start 2015-01-01 --end auto --rnn lstm --lookback 60 --epochs 30
```

3. **Predict next-day close**
```bash
python src/predict.py --ticker AAPL --lookback 60
```

---

## 🛠 Requirements
- pandas, numpy
- scikit-learn
- tensorflow
- yfinance
- joblib
- matplotlib

Install with:
```bash
pip install -r requirements.txt
```

---
